import base64
import ctypes
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import bpy
import blf
import gpu
from mathutils import Vector
from bl_ui import space_time
from gpu_extras.batch import batch_for_shader

bl_info = {
    "name": "Weidmuller Utils",
    "author": "Dawid",
    "version": (0, 0, 1),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar",
    "category": "3D View",
}


TIMELINE_BLOCKS = []
TIMELINE_BLOCK_RECTS = []
TIMELINE_DRAW_HANDLER = None
TIMELINE_KEYMAPS = []
TIMELINE_TIMER_INTERVAL = 0.5
TIMELINE_DATABASE_SYNC_INTERVAL = 10.0
TIMELINE_SYNC_THREAD = None
TIMELINE_SYNC_RESULT = None
TIMELINE_SYNC_NEXT_AT = 0.0
TIMELINE_SYNC_LOCK = threading.Lock()
TIMELINE_SESSION = {
    "access_token": None,
    "refresh_token": None,
}
ORIGINAL_TIME_DRAW_HEADER = None
# Stable identifier of the highlighted entry. Keeping an index avoids relying
# on dictionary equality or object identity after a JSON refresh.

TIMELINE_BLOCK_COLORS = {
    "loop": (0.396, 0.616, 0.949, 0.78),
    "transition": (0.996, 0.624, 0.302, 0.78),
    "story": (0.561, 0.498, 0.933, 0.78),
}

SUPABASE_URL = "https://bpmziyioiszufnyxlqse.supabase.co"
SUPABASE_PUBLISHABLE_KEY = "sb_publishable_8vSjd-U5aeXXspEcCNf8LA_RzeMnz-j"
SUPABASE_TIMELINE_SLUG = "main"


class _WindowsDataBlob(ctypes.Structure):
    _fields_ = (
        ("size", ctypes.c_uint32),
        ("data", ctypes.POINTER(ctypes.c_ubyte)),
    )


def _protect_windows_secret(value):
    if not value or os.name != "nt":
        return ""
    raw = value.encode("utf-8")
    raw_buffer = ctypes.create_string_buffer(raw)
    input_blob = _WindowsDataBlob(
        len(raw),
        ctypes.cast(raw_buffer, ctypes.POINTER(ctypes.c_ubyte)),
    )
    output_blob = _WindowsDataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    if not crypt32.CryptProtectData(
        ctypes.byref(input_blob),
        None,
        None,
        None,
        None,
        0x01,
        ctypes.byref(output_blob),
    ):
        raise ctypes.WinError()
    try:
        encrypted = ctypes.string_at(output_blob.data, output_blob.size)
        return base64.b64encode(encrypted).decode("ascii")
    finally:
        kernel32.LocalFree(output_blob.data)


def _unprotect_windows_secret(value):
    if not value or os.name != "nt":
        return ""
    encrypted = base64.b64decode(value.encode("ascii"), validate=True)
    encrypted_buffer = ctypes.create_string_buffer(encrypted)
    input_blob = _WindowsDataBlob(
        len(encrypted),
        ctypes.cast(encrypted_buffer, ctypes.POINTER(ctypes.c_ubyte)),
    )
    output_blob = _WindowsDataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    if not crypt32.CryptUnprotectData(
        ctypes.byref(input_blob),
        None,
        None,
        None,
        None,
        0x01,
        ctypes.byref(output_blob),
    ):
        raise ctypes.WinError()
    try:
        decrypted = ctypes.string_at(output_blob.data, output_blob.size)
        return decrypted.decode("utf-8")
    finally:
        kernel32.LocalFree(output_blob.data)


def _get_addon_preferences():
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def _remember_timeline_database_session():
    preferences = _get_addon_preferences()
    if preferences is None:
        return
    if not preferences.remember_database_login:
        preferences.encrypted_database_refresh_token = ""
        return
    refresh_token = TIMELINE_SESSION.get("refresh_token")
    if not refresh_token:
        return
    try:
        preferences.encrypted_database_refresh_token = _protect_windows_secret(
            refresh_token
        )
    except Exception as error:
        print(f"Weidmuller Utils: could not remember database session: {error}")


def _restore_timeline_database_session():
    preferences = _get_addon_preferences()
    if (
        preferences is None
        or not preferences.remember_database_login
        or not preferences.encrypted_database_refresh_token
    ):
        return False
    try:
        TIMELINE_SESSION["access_token"] = None
        TIMELINE_SESSION["refresh_token"] = _unprotect_windows_secret(
            preferences.encrypted_database_refresh_token
        )
        return bool(TIMELINE_SESSION["refresh_token"])
    except Exception as error:
        print(f"Weidmuller Utils: could not restore database session: {error}")
        preferences.encrypted_database_refresh_token = ""
        return False


def _forget_timeline_database_session():
    preferences = _get_addon_preferences()
    if preferences is not None:
        preferences.encrypted_database_refresh_token = ""


def _camera_area_items(self, context):
    areas = set()
    for block in TIMELINE_BLOCKS:
        camera_name = str(block.get("camera", ""))
        match = re.match(r"^[A-Za-z]+", camera_name)
        if match:
            areas.add(match.group(0))

    if not areas:
        return [("ALL", "All areas", "Show all cameras")]

    return [("ALL", "All areas", "Show all cameras")] + [
        (area, area, f"Obszar kamer {area}")
        for area in sorted(areas)
    ]


def _refresh_camera_manager_items(context):
    scene = getattr(context, "scene", None) if context else None
    if not scene:
        return
    settings = getattr(scene, "blenderutils_camera_manager_settings", None)
    if not settings:
        return

    settings.camera_items.clear()
    cameras = sorted({str(block.get("camera", "")) for block in TIMELINE_BLOCKS})
    for camera_name in cameras:
        item = settings.camera_items.add()
        item.name = camera_name
        match = re.match(r"^[A-Za-z]+", camera_name)
        item.area = match.group(0) if match else "NONE"
        item.frame_count = sum(
            int(block["end_frame"]) - int(block["start_frame"]) + 1
            for block in TIMELINE_BLOCKS
            if str(block.get("camera", "")) == camera_name
        )
        camera_object = bpy.data.objects.get(camera_name)
        item.exists_in_scene = bool(camera_object and camera_object.type == "CAMERA")


def _refresh_camera_manager_statuses():
    changed = False
    for scene in bpy.data.scenes:
        settings = getattr(scene, "blenderutils_camera_manager_settings", None)
        if not settings:
            continue
        for item in settings.camera_items:
            camera_object = bpy.data.objects.get(item.name)
            exists = bool(camera_object and camera_object.type == "CAMERA")
            if item.exists_in_scene != exists:
                item.exists_in_scene = exists
                changed = True

    if changed:
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()


def _camera_exists(camera_name):
    camera_object = bpy.data.objects.get(camera_name)
    return camera_object is not None and camera_object.type == "CAMERA"


def _timeline_preview_path(settings, camera_name):
    folder = bpy.path.abspath(settings.timeline_preview_folder)
    if not folder or not camera_name:
        return None

    for extension in (".png", ".PNG", ".jpg", ".JPG", ".jpeg", ".JPEG"):
        candidate = os.path.join(folder, f"{camera_name}{extension}")
        if os.path.isfile(candidate):
            return candidate
    return None


def _set_timeline_preview_camera(context, camera_name):
    settings = getattr(context.scene, "blenderutils_timeline_settings", None)
    if settings is None:
        return

    settings.active_preview_camera = str(camera_name or "")
    settings.preview_image = None
    image_path = _timeline_preview_path(settings, settings.active_preview_camera)
    if not image_path:
        return

    _show_external_timeline_preview(image_path)


def _show_external_timeline_preview(image_path):
    global TIMELINE_PREVIEW_THREAD, TIMELINE_PREVIEW_HWND, TIMELINE_PREVIEW_STOP_EVENT

    if os.name != "nt":
        return

    _close_external_timeline_preview()
    TIMELINE_PREVIEW_STOP_EVENT = threading.Event()
    TIMELINE_PREVIEW_THREAD = threading.Thread(
        target=_timeline_preview_window_thread,
        args=(image_path, TIMELINE_PREVIEW_STOP_EVENT),
        daemon=True,
    )
    TIMELINE_PREVIEW_THREAD.start()


def _close_external_timeline_preview():
    global TIMELINE_PREVIEW_THREAD, TIMELINE_PREVIEW_HWND, TIMELINE_PREVIEW_STOP_EVENT

    if TIMELINE_PREVIEW_STOP_EVENT is not None:
        TIMELINE_PREVIEW_STOP_EVENT.set()
    if TIMELINE_PREVIEW_HWND:
        try:
            ctypes.windll.user32.PostMessageW(TIMELINE_PREVIEW_HWND, 0x0010, 0, 0)
        except (AttributeError, OSError):
            pass
        TIMELINE_PREVIEW_HWND = None
    if TIMELINE_PREVIEW_THREAD is not None and TIMELINE_PREVIEW_THREAD is not threading.current_thread():
        TIMELINE_PREVIEW_THREAD.join(timeout=1.0)
    TIMELINE_PREVIEW_THREAD = None
    TIMELINE_PREVIEW_STOP_EVENT = None


def _timeline_preview_window_thread(image_path, stop_event):
    global TIMELINE_PREVIEW_HWND, TIMELINE_PREVIEW_CALLBACK

    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    gdiplus = ctypes.windll.gdiplus
    kernel32 = ctypes.windll.kernel32

    class GdiplusStartupInput(ctypes.Structure):
        _fields_ = [
            ("GdiplusVersion", ctypes.c_uint32),
            ("DebugEventCallback", ctypes.c_void_p),
            ("SuppressBackgroundThread", ctypes.c_bool),
            ("SuppressExternalCodecs", ctypes.c_bool),
        ]

    class WNDCLASSW(ctypes.Structure):
        _fields_ = [
            ("style", ctypes.c_uint),
            ("lpfnWndProc", ctypes.c_void_p),
            ("cbClsExtra", ctypes.c_int),
            ("cbWndExtra", ctypes.c_int),
            ("hInstance", ctypes.c_void_p),
            ("hIcon", ctypes.c_void_p),
            ("hCursor", ctypes.c_void_p),
            ("hbrBackground", ctypes.c_void_p),
            ("lpszMenuName", ctypes.c_wchar_p),
            ("lpszClassName", ctypes.c_wchar_p),
        ]

    class RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    class PAINTSTRUCT(ctypes.Structure):
        _fields_ = [("hdc", ctypes.c_void_p), ("fErase", ctypes.c_int), ("rcPaint", RECT), ("fRestore", ctypes.c_int), ("fIncUpdate", ctypes.c_int), ("rgbReserved", ctypes.c_ubyte * 32)]

    token = ctypes.c_void_p()
    startup = GdiplusStartupInput(1, None, False, False)
    if gdiplus.GdiplusStartup(ctypes.byref(token), ctypes.byref(startup), None) != 0:
        return

    bitmap = ctypes.c_void_p()
    image_w = ctypes.c_uint(1)
    image_h = ctypes.c_uint(1)
    try:
        if stop_event.is_set():
            return
        if gdiplus.GdipCreateBitmapFromFile(ctypes.c_wchar_p(image_path), ctypes.byref(bitmap)) != 0:
            return
        gdiplus.GdipGetImageWidth(bitmap, ctypes.byref(image_w))
        gdiplus.GdipGetImageHeight(bitmap, ctypes.byref(image_h))

        class_name = "WeidmullerTimelinePreviewWindow"
        wndproc_type = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p)

        def wndproc(hwnd, message, wparam, lparam):
            if message == 0x000F:
                paint = PAINTSTRUCT()
                hdc = user32.BeginPaint(hwnd, ctypes.byref(paint))
                graphics = ctypes.c_void_p()
                gdiplus.GdipCreateFromHDC(hdc, ctypes.byref(graphics))
                rect = RECT()
                user32.GetClientRect(hwnd, ctypes.byref(rect))
                client_w = max(1, rect.right - rect.left)
                client_h = max(1, rect.bottom - rect.top)
                border = 5
                orange_brush = gdi32.CreateSolidBrush(0x000078EF)
                old_brush = gdi32.SelectObject(hdc, orange_brush)
                gdi32.RoundRect(hdc, 0, 0, client_w, client_h, 28, 28)
                gdi32.SelectObject(hdc, old_brush)
                gdi32.DeleteObject(orange_brush)
                black_brush = gdi32.CreateSolidBrush(0x00000000)
                old_brush = gdi32.SelectObject(hdc, black_brush)
                gdi32.FillRect(hdc, ctypes.byref(RECT(border, border, client_w - border, client_h - border)), black_brush)
                gdi32.SelectObject(hdc, old_brush)
                gdi32.DeleteObject(black_brush)
                inner_w = max(1, client_w - border * 2)
                inner_h = max(1, client_h - border * 2)
                scale = min(inner_w / max(1, image_w.value), inner_h / max(1, image_h.value))
                draw_w = int(image_w.value * scale)
                draw_h = int(image_h.value * scale)
                gdiplus.GdipDrawImageRectI(graphics, bitmap, border + (inner_w - draw_w) // 2, border + (inner_h - draw_h) // 2, draw_w, draw_h)
                gdiplus.GdipDeleteGraphics(graphics)
                user32.EndPaint(hwnd, ctypes.byref(paint))
                return 0
            if message == 0x0010:
                user32.DestroyWindow(hwnd)
                return 0
            if message == 0x0002:
                user32.PostQuitMessage(0)
                return 0
            return user32.DefWindowProcW(hwnd, message, wparam, lparam)

        TIMELINE_PREVIEW_CALLBACK = wndproc_type(wndproc)
        instance = kernel32.GetModuleHandleW(None)
        cursor = user32.LoadCursorW(None,  IDC_ARROW := 32512)
        window_class = WNDCLASSW(0, ctypes.cast(TIMELINE_PREVIEW_CALLBACK, ctypes.c_void_p), 0, 0, instance, None, cursor, None, None, class_name)
        user32.RegisterClassW(ctypes.byref(window_class))
        width = min(1000, max(360, image_w.value + 32))
        height = min(800, max(260, image_h.value + 32))
        hwnd = user32.CreateWindowExW(0x00000080 | 0x00000008, class_name, "Camera Preview", 0x10CF0000, 100, 100, width, height, None, None, instance, None)
        if not hwnd:
            return
        rounded_region = gdi32.CreateRoundRectRgn(0, 0, width + 1, height + 1, 28, 28)
        user32.SetWindowRgn(hwnd, rounded_region, True)
        if stop_event.is_set():
            user32.DestroyWindow(hwnd)
            return
        TIMELINE_PREVIEW_HWND = hwnd
        user32.ShowWindow(hwnd, 5)
        user32.UpdateWindow(hwnd)
        message = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(message))
            user32.DispatchMessageW(ctypes.byref(message))
    finally:
        if bitmap:
            gdiplus.GdipDisposeImage(bitmap)
        gdiplus.GdiplusShutdown(token)
        if TIMELINE_PREVIEW_HWND:
            TIMELINE_PREVIEW_HWND = None


def _clear_timeline_preview_before_save(_dummy):
    for scene in bpy.data.scenes:
        settings = getattr(scene, "blenderutils_timeline_settings", None)
        if settings is None:
            continue
        image = settings.preview_image
        settings.preview_image = None
        if image is not None and image.users == 0:
            bpy.data.images.remove(image)


def _restore_timeline_preview_after_save(_dummy):
    for scene in bpy.data.scenes:
        settings = getattr(scene, "blenderutils_timeline_settings", None)
        if settings is not None and settings.active_preview_camera:
            _set_timeline_preview_camera(
                type("PreviewContext", (), {"scene": scene})(),
                settings.active_preview_camera,
            )


def _camera_timeline_blocks(camera_name):
    return sorted(
        [block for block in TIMELINE_BLOCKS if block.get("camera") == camera_name],
        key=lambda block: (block["start_frame"], block["end_frame"]),
    )


def _insert_camera_timeline_keyframes(camera, camera_name):
    for block in _camera_timeline_blocks(camera_name):
        for frame in (block["start_frame"], block["end_frame"]):
            camera.keyframe_insert(data_path="location", frame=frame)
            camera.keyframe_insert(data_path="rotation_euler", frame=frame)


def _camera_object_keyframes(camera):
    action = getattr(getattr(camera, "animation_data", None), "action", None)
    if action is None:
        return set()
    return {
        int(round(point.co.x))
        for fcurve in action.fcurves
        for point in fcurve.keyframe_points
    }


def _camera_missing_timeline_keyframes(camera, camera_name):
    expected_frames = {
        frame
        for block in _camera_timeline_blocks(camera_name)
        for frame in (block["start_frame"], block["end_frame"])
    }
    return sorted(expected_frames - _camera_object_keyframes(camera))


def _animated_property_value(id_block, data_path, array_index, frame, default):
    action = getattr(getattr(id_block, "animation_data", None), "action", None)
    if action is None:
        return default

    for fcurve in action.fcurves:
        if fcurve.data_path == data_path and fcurve.array_index == array_index:
            return fcurve.evaluate(frame)
    return default


def _object_location_at_frame(obj, frame):
    return Vector([
        _animated_property_value(obj, "location", index, frame, obj.location[index])
        for index in range(3)
    ])


def _camera_tracking_target(camera):
    return next(
        (
            constraint.target
            for constraint in camera.constraints
            if constraint.type in {"TRACK_TO", "DAMPED_TRACK"} and constraint.target
        ),
        None,
    )


def _transition_validation_issues(camera, camera_name):
    transition_blocks = [
        block for block in _camera_timeline_blocks(camera_name)
        if block.get("type") == "transition"
    ]
    components = [part.strip() for part in camera_name.split("-") if part.strip()]
    if len(components) != 2 or not transition_blocks:
        return None

    transition_block = transition_blocks[0]
    start_frame = transition_block["start_frame"]
    end_frame = transition_block["end_frame"]
    start_camera = bpy.data.objects.get(components[0])
    end_camera = bpy.data.objects.get(components[1])
    issues = {"start": [], "end": []}

    if start_camera is None or start_camera.type != "CAMERA":
        issues["start"].append(f"Source camera {components[0]} is missing")
    if end_camera is None or end_camera.type != "CAMERA":
        issues["end"].append(f"Source camera {components[1]} is missing")
    if issues["start"] or issues["end"]:
        return components, issues

    follow_path = next(
        (constraint for constraint in camera.constraints if constraint.type == "FOLLOW_PATH"),
        None,
    )
    if follow_path is None or follow_path.target is None or follow_path.target.type != "CURVE":
        issues["start"].append("Follow Path curve is missing")
        issues["end"].append("Follow Path curve is missing")
        return components, issues

    spline = next((spline for spline in follow_path.target.data.splines if spline.type == "BEZIER"), None)
    if spline is None or len(spline.bezier_points) < 2:
        issues["start"].append("Curve endpoints are missing")
        issues["end"].append("Curve endpoints are missing")
        return components, issues

    tolerance = 0.001
    expected_start_location = _object_location_at_frame(start_camera, start_frame)
    expected_end_location = _object_location_at_frame(end_camera, end_frame)
    if (Vector(spline.bezier_points[0].co) - expected_start_location).length > tolerance:
        issues["start"].append("Location does not match")
    if (Vector(spline.bezier_points[1].co) - expected_end_location).length > tolerance:
        issues["end"].append("Location does not match")

    follow_path_path = follow_path.path_from_id("offset_factor")
    start_factor = _animated_property_value(camera, follow_path_path, 0, start_frame, follow_path.offset_factor)
    end_factor = _animated_property_value(camera, follow_path_path, 0, end_frame, follow_path.offset_factor)
    if abs(start_factor) > tolerance:
        issues["start"].append("Follow Path does not start at 0")
    if abs(end_factor - 1.0) > tolerance:
        issues["end"].append("Follow Path does not end at 1")

    start_lens = _animated_property_value(start_camera.data, "lens", 0, start_frame, start_camera.data.lens)
    end_lens = _animated_property_value(end_camera.data, "lens", 0, end_frame, end_camera.data.lens)
    transition_start_lens = _animated_property_value(camera.data, "lens", 0, start_frame, camera.data.lens)
    transition_end_lens = _animated_property_value(camera.data, "lens", 0, end_frame, camera.data.lens)
    if abs(transition_start_lens - start_lens) > tolerance:
        issues["start"].append("Focal length does not match")
    if abs(transition_end_lens - end_lens) > tolerance:
        issues["end"].append("Focal length does not match")

    tracking_target = _camera_tracking_target(camera)
    start_target = _camera_tracking_target(start_camera)
    end_target = _camera_tracking_target(end_camera)
    if tracking_target is None:
        issues["start"].append("Track To target is missing")
        issues["end"].append("Track To target is missing")
        return components, issues

    expected_start_target = (
        _object_location_at_frame(start_target, start_frame)
        if start_target else _camera_tracking_point(start_camera)
    )
    expected_end_target = (
        _object_location_at_frame(end_target, end_frame)
        if end_target else _camera_tracking_point(end_camera)
    )
    if (_object_location_at_frame(tracking_target, start_frame) - expected_start_target).length > tolerance:
        issues["start"].append("Tracking target does not match")
    if (_object_location_at_frame(tracking_target, end_frame) - expected_end_target).length > tolerance:
        issues["end"].append("Tracking target does not match")

    return components, issues


def _fix_transition_camera_issues(camera, camera_name):
    transition_blocks = [
        block for block in _camera_timeline_blocks(camera_name)
        if block.get("type") == "transition"
    ]
    components = [part.strip() for part in camera_name.split("-") if part.strip()]
    if len(components) != 2 or not transition_blocks:
        return False

    start_camera = bpy.data.objects.get(components[0])
    end_camera = bpy.data.objects.get(components[1])
    if (
        start_camera is None or start_camera.type != "CAMERA" or
        end_camera is None or end_camera.type != "CAMERA"
    ):
        return False

    transition_block = transition_blocks[0]
    start_frame = transition_block["start_frame"]
    end_frame = transition_block["end_frame"]
    follow_path = next(
        (constraint for constraint in camera.constraints if constraint.type == "FOLLOW_PATH"),
        None,
    )
    if follow_path is None or follow_path.target is None or follow_path.target.type != "CURVE":
        return False

    spline = next(
        (spline for spline in follow_path.target.data.splines if spline.type == "BEZIER"),
        None,
    )
    if spline is None or len(spline.bezier_points) < 2:
        return False

    spline.bezier_points[0].co = _object_location_at_frame(start_camera, start_frame)
    spline.bezier_points[1].co = _object_location_at_frame(end_camera, end_frame)
    follow_path.offset_factor = 0.0
    follow_path.keyframe_insert(data_path="offset_factor", frame=start_frame)
    follow_path.offset_factor = 1.0
    follow_path.keyframe_insert(data_path="offset_factor", frame=end_frame)

    start_lens = _animated_property_value(start_camera.data, "lens", 0, start_frame, start_camera.data.lens)
    end_lens = _animated_property_value(end_camera.data, "lens", 0, end_frame, end_camera.data.lens)
    camera.data.lens = start_lens
    camera.data.keyframe_insert(data_path="lens", frame=start_frame)
    camera.data.lens = end_lens
    camera.data.keyframe_insert(data_path="lens", frame=end_frame)
    camera.data.lens = start_lens

    start_target = _camera_tracking_target(start_camera)
    end_target = _camera_tracking_target(end_camera)
    _add_tracking_target(
        camera,
        _object_location_at_frame(start_target, start_frame)
        if start_target else _camera_tracking_point(start_camera),
        _object_location_at_frame(end_target, end_frame)
        if end_target else _camera_tracking_point(end_camera),
        start_frame,
        end_frame,
    )
    return True


def _camera_tracking_point(camera):
    for constraint in camera.constraints:
        if constraint.type in {"TRACK_TO", "DAMPED_TRACK"} and constraint.target:
            return constraint.target.matrix_world.translation.copy()

    direction = camera.matrix_world.to_quaternion() @ Vector((0.0, 0.0, -1.0))
    return camera.matrix_world.translation + direction.normalized() * 10.0


def _add_tracking_target(camera, start_point, end_point=None, start_frame=None, end_frame=None):
    target_name = f"Empty_{camera.name}"
    target = bpy.data.objects.get(target_name)
    if target is None:
        target = bpy.data.objects.new(target_name, None)
        target.empty_display_type = "PLAIN_AXES"
        target.empty_display_size = 0.35
        camera.users_collection[0].objects.link(target)

    target.location = start_point
    if end_point is not None and start_frame is not None and end_frame is not None:
        target.keyframe_insert(data_path="location", frame=start_frame)
        target.location = end_point
        target.keyframe_insert(data_path="location", frame=end_frame)
        target.location = start_point

    for constraint in list(camera.constraints):
        if constraint.type == "TRACK_TO":
            camera.constraints.remove(constraint)

    tracking = camera.constraints.new(type="TRACK_TO")
    tracking.name = "Track To Camera Target"
    tracking.target = target
    tracking.track_axis = "TRACK_NEGATIVE_Z"
    tracking.up_axis = "UP_Y"
    return target


def _iter_animatable_ids_for_object(obj):
    yield obj

    data = getattr(obj, "data", None)
    if data is not None:
        yield data

        shape_keys = getattr(data, "shape_keys", None)
        if shape_keys is not None:
            yield shape_keys


def _get_selected_object_frame_range(obj):
    keyframes = []

    for anim_owner in _iter_animatable_ids_for_object(obj):
        animation_data = getattr(anim_owner, "animation_data", None)
        action = getattr(animation_data, "action", None)
        if action is None:
            continue

        for fcurve in action.fcurves:
            for keyframe_point in fcurve.keyframe_points:
                keyframes.append(float(keyframe_point.co.x))

    if not keyframes:
        return None

    return int(min(keyframes)), int(max(keyframes))


def _darken_color(color, factor=0.55):
    return (
        color[0] * factor,
        color[1] * factor,
        color[2] * factor,
        color[3],
    )


def _draw_rectangle(shader, x, y, width, height, color):
    vertices = (
        (x, y),
        (x + width, y),
        (x + width, y + height),
        (x, y + height),
    )
    indices = ((0, 1, 2), (0, 2, 3))

    batch = batch_for_shader(shader, "TRIS", {"pos": vertices}, indices=indices)
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_hatch_pattern(shader, x, y, width, height, color, spacing=8, line_width=1.0):
    vertices = []
    start_offset = -height
    end_offset = width
    offset = start_offset

    while offset <= end_offset:
        line_start_x = x + offset
        line_start_y = y
        line_end_x = x + offset + height
        line_end_y = y + height

        clip_start_x = max(x, min(x + width, line_start_x))
        clip_start_y = y + (clip_start_x - line_start_x)
        clip_end_x = max(x, min(x + width, line_end_x))
        clip_end_y = y + (clip_end_x - line_start_x)

        if clip_start_y < y:
            adjust = y - clip_start_y
            clip_start_x += adjust
            clip_start_y = y

        if clip_end_y > y + height:
            adjust = clip_end_y - (y + height)
            clip_end_x -= adjust
            clip_end_y = y + height

        if clip_start_x <= x + width and clip_end_x >= x and clip_start_y <= y + height and clip_end_y >= y:
            vertices.append((clip_start_x, clip_start_y))
            vertices.append((clip_end_x, clip_end_y))

        offset += spacing

    if not vertices:
        return

    batch = batch_for_shader(shader, "LINES", {"pos": vertices})
    shader.bind()
    shader.uniform_float("color", color)
    gpu.state.line_width_set(line_width)
    batch.draw(shader)
    gpu.state.line_width_set(1.0)


def _draw_rectangle_outline(shader, x, y, width, height, color):
    vertices = (
        (x, y),
        (x + width, y),
        (x + width, y),
        (x + width, y + height),
        (x + width, y + height),
        (x, y + height),
        (x, y + height),
        (x, y),
    )

    batch = batch_for_shader(shader, "LINES", {"pos": vertices})
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def _timeline_block_type_is_visible(settings, block_type):
    if settings is None:
        return True
    property_name = {
        "loop": "show_loop_blocks",
        "transition": "show_transition_blocks",
        "story": "show_story_blocks",
    }.get(str(block_type))
    return property_name is None or bool(getattr(settings, property_name, True))


def _timeline_blocks_with_lanes(settings=None):
    indexed_blocks = sorted(
        (
            (index, block)
            for index, block in enumerate(TIMELINE_BLOCKS)
            if _timeline_block_type_is_visible(settings, block.get("type"))
        ),
        key=lambda item: (item[1]["start_frame"], item[1]["end_frame"], item[0]),
    )
    blocks_with_lanes = []
    lane_intervals = []

    def can_place(block, lane_index):
        if lane_index >= len(lane_intervals):
            return True
        return all(
            block["end_frame"] < interval_start
            or block["start_frame"] > interval_end
            for interval_start, interval_end in lane_intervals[lane_index]
        )

    def occupy(original_index, block, lane_index):
        while len(lane_intervals) <= lane_index:
            lane_intervals.append([])
        lane_intervals[lane_index].append(
            (block["start_frame"], block["end_frame"])
        )
        blocks_with_lanes.append((original_index, block, lane_index))

    for original_index, block in indexed_blocks:
        if not block.get("lane_locked", False):
            continue
        lane_index = max(0, int(block.get("lane", 0)))
        while not can_place(block, lane_index):
            lane_index += 1
        occupy(original_index, block, lane_index)

    for original_index, block in indexed_blocks:
        if block.get("lane_locked", False):
            continue
        lane_index = 0
        while not can_place(block, lane_index):
            lane_index += 1
        occupy(original_index, block, lane_index)

    return sorted(blocks_with_lanes, key=lambda item: item[0])


def _draw_timeline_blocks():
    global TIMELINE_BLOCK_RECTS

    context = bpy.context
    area = context.area
    region = context.region

    settings = getattr(context.scene, "blenderutils_timeline_settings", None)
    if settings is not None and not settings.show_timeline_blocks:
        TIMELINE_BLOCK_RECTS = []
        return

    if not TIMELINE_BLOCKS or not area or not region:
        return

    if area.type != "DOPESHEET_EDITOR" or region.type != "WINDOW":
        return

    view_2d = region.view2d
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")

    gpu.state.blend_set("ALPHA")
    gpu.state.line_width_set(1.0)

    lane_height = 22
    lane_gap = 4
    bottom_padding = 20
    TIMELINE_BLOCK_RECTS = []

    for _, block, lane_index in _timeline_blocks_with_lanes(settings):
        start_frame = block["start_frame"]
        end_frame = block["end_frame"]
        block_type = block["type"]
        camera_name = block["camera"]

        start_x = view_2d.view_to_region(start_frame, 0, clip=False)[0]
        end_x = view_2d.view_to_region(end_frame, 0, clip=False)[0]

        x = min(start_x, end_x)
        width = abs(end_x - start_x)
        if width < 2:
            continue

        y = bottom_padding + lane_index * (lane_height + lane_gap)
        base_color = TIMELINE_BLOCK_COLORS.get(block_type, (0.60, 0.60, 0.60, 0.72))
        camera_exists = _camera_exists(camera_name)
        color = base_color if camera_exists else _darken_color(base_color)

        # Use object identity here. Two JSON entries can legitimately contain
        # the same values but still represent separate timeline blocks.
        _draw_rectangle(shader, x, y, width, lane_height, color)
        if not camera_exists:
            hatch_color = _darken_color(base_color, 0.35)
            _draw_hatch_pattern(shader, x, y, width, lane_height, hatch_color, spacing=8, line_width=2.0)
        _draw_rectangle_outline(shader, x, y, width, lane_height, (0.0, 0.0, 0.0, 0.62))
        TIMELINE_BLOCK_RECTS.append(
            {
                "block": block,
                "x": x,
                "y": y,
                "width": width,
                "height": lane_height,
            }
        )

        if width > 42:
            label = camera_name
            blf.size(0, 11)
            blf.color(0, 1.0, 1.0, 1.0, 1.0)
            blf.position(0, x + 6, y + 6, 0)
            blf.draw(0, label)

    gpu.state.blend_set("NONE")


class TimelineDatabaseError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def _database_json_request(url, method="GET", payload=None, access_token=None):
    headers = {
        "apikey": SUPABASE_PUBLISHABLE_KEY,
        "Accept": "application/json",
    }
    body = None
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"

    request = urllib.request.Request(
        url,
        data=body,
        headers=headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=8.0) as response:
            response_body = response.read().decode("utf-8")
    except urllib.error.HTTPError as error:
        try:
            error_body = error.read().decode("utf-8")
            error_data = json.loads(error_body)
            message = (
                error_data.get("message")
                or error_data.get("error_description")
                or error_data.get("error")
                or f"HTTP {error.code}"
            )
        except Exception:
            message = f"HTTP {error.code}"
        raise TimelineDatabaseError(str(message), error.code) from error
    except urllib.error.URLError as error:
        reason = getattr(error, "reason", error)
        raise TimelineDatabaseError(f"Network error: {reason}") from error
    except TimeoutError as error:
        raise TimelineDatabaseError("Database request timed out.") from error

    if not response_body:
        return None
    try:
        return json.loads(response_body)
    except json.JSONDecodeError as error:
        raise TimelineDatabaseError("Database returned invalid JSON.") from error


def _login_to_timeline_database(access_password):
    if not access_password:
        raise TimelineDatabaseError("Enter the access password.")
    session = _database_json_request(
        f"{SUPABASE_URL}/functions/v1/timeline-login",
        method="POST",
        payload={"password": access_password},
    )
    access_token = session.get("access_token") if isinstance(session, dict) else None
    refresh_token = session.get("refresh_token") if isinstance(session, dict) else None
    if not access_token or not refresh_token:
        raise TimelineDatabaseError("The login service did not return a session.")
    TIMELINE_SESSION["access_token"] = access_token
    TIMELINE_SESSION["refresh_token"] = refresh_token


def _refresh_timeline_database_session():
    refresh_token = TIMELINE_SESSION.get("refresh_token")
    if not refresh_token:
        raise TimelineDatabaseError("The database session has expired. Connect again.")
    session = _database_json_request(
        f"{SUPABASE_URL}/auth/v1/token?grant_type=refresh_token",
        method="POST",
        payload={"refresh_token": refresh_token},
    )
    access_token = session.get("access_token") if isinstance(session, dict) else None
    next_refresh_token = session.get("refresh_token") if isinstance(session, dict) else None
    if not access_token or not next_refresh_token:
        raise TimelineDatabaseError("Could not refresh the database session.")
    TIMELINE_SESSION["access_token"] = access_token
    TIMELINE_SESSION["refresh_token"] = next_refresh_token


def _database_get(path, query):
    url = f"{SUPABASE_URL}{path}?{urllib.parse.urlencode(query)}"
    try:
        return _database_json_request(
            url,
            access_token=TIMELINE_SESSION.get("access_token"),
        )
    except TimelineDatabaseError as error:
        if error.status != 401:
            raise
    _refresh_timeline_database_session()
    return _database_json_request(
        url,
        access_token=TIMELINE_SESSION.get("access_token"),
    )


def _validate_database_timeline_blocks(timeline_blocks):
    if not isinstance(timeline_blocks, list):
        raise TimelineDatabaseError("Database did not return a block list.")
    loaded_blocks = []

    for index, block in enumerate(timeline_blocks, start=1):
        if not isinstance(block, dict):
            raise TimelineDatabaseError(f"Block {index} is not an object.")

        missing_keys = {"camera", "type", "start_frame", "end_frame"} - set(block)
        if missing_keys:
            keys_text = ", ".join(sorted(missing_keys))
            raise TimelineDatabaseError(
                f"Block {index} is missing fields: {keys_text}."
            )

        try:
            start_frame = int(block["start_frame"])
            end_frame = int(block["end_frame"])
            lane = max(0, int(block.get("lane", 0)))
        except (TypeError, ValueError):
            raise TimelineDatabaseError(
                f"Block {index} has invalid frame or lane values."
            )

        if end_frame < start_frame:
            raise TimelineDatabaseError(
                f"Block {index} has end_frame before start_frame."
            )

        loaded_blocks.append(
            {
                "camera": str(block["camera"]),
                "type": str(block["type"]),
                "start_frame": start_frame,
                "end_frame": end_frame,
                "lane": lane,
                "lane_locked": bool(block.get("lane_locked", False)),
            }
        )

    return loaded_blocks


def _fetch_timeline_database_blocks():
    timelines = _database_get(
        "/rest/v1/timelines",
        {
            "slug": f"eq.{SUPABASE_TIMELINE_SLUG}",
            "select": "id",
            "limit": "1",
        },
    )
    if not isinstance(timelines, list) or not timelines:
        raise TimelineDatabaseError("Timeline 'main' was not found.")
    timeline_id = timelines[0].get("id")
    if not timeline_id:
        raise TimelineDatabaseError("Timeline record has no ID.")

    blocks = _database_get(
        "/rest/v1/timeline_blocks",
        {
            "timeline_id": f"eq.{timeline_id}",
            "select": "camera,type,start_frame,end_frame,lane,lane_locked",
            "order": "start_frame.asc,end_frame.asc",
        },
    )
    return _validate_database_timeline_blocks(blocks)


def _set_timeline_blocks(context, blocks):
    global TIMELINE_BLOCKS
    TIMELINE_BLOCKS = blocks
    _tag_timeline_redraw(context)


def _set_timeline_database_status(status, message=""):
    for scene in bpy.data.scenes:
        settings = getattr(scene, "blenderutils_timeline_settings", None)
        if settings is None:
            continue
        settings.database_status = status
        settings.database_message = message


def _timeline_database_sync_worker(access_password):
    global TIMELINE_SYNC_RESULT, TIMELINE_SYNC_THREAD
    try:
        if not TIMELINE_SESSION.get("access_token"):
            if TIMELINE_SESSION.get("refresh_token"):
                _refresh_timeline_database_session()
            else:
                _login_to_timeline_database(access_password)
        blocks = _fetch_timeline_database_blocks()
        result = {
            "blocks": blocks,
            "error": None,
            "synced_at": time.strftime("%H:%M:%S"),
        }
    except Exception as error:
        result = {
            "blocks": None,
            "error": str(error),
            "synced_at": None,
        }
    with TIMELINE_SYNC_LOCK:
        TIMELINE_SYNC_RESULT = result
        TIMELINE_SYNC_THREAD = None


def _start_timeline_database_sync(access_password=""):
    global TIMELINE_SYNC_THREAD, TIMELINE_SYNC_NEXT_AT
    with TIMELINE_SYNC_LOCK:
        if TIMELINE_SYNC_THREAD is not None:
            return False
        TIMELINE_SYNC_THREAD = threading.Thread(
            target=_timeline_database_sync_worker,
            args=(str(access_password or ""),),
            name="WeidmullerTimelineSync",
            daemon=True,
        )
        TIMELINE_SYNC_NEXT_AT = time.monotonic() + TIMELINE_DATABASE_SYNC_INTERVAL
        TIMELINE_SYNC_THREAD.start()
    return True


def _tag_timeline_redraw(context):
    screens = []

    if context and context.screen:
        screens.append(context.screen)

    window_manager = bpy.context.window_manager
    for window in window_manager.windows:
        if window.screen and window.screen not in screens:
            screens.append(window.screen)

    for screen in screens:
        for area in screen.areas:
            if area.type == "DOPESHEET_EDITOR":
                area.tag_redraw()


def _timeline_database_auto_refresh_timer():
    global TIMELINE_SYNC_RESULT
    with TIMELINE_SYNC_LOCK:
        result = TIMELINE_SYNC_RESULT
        TIMELINE_SYNC_RESULT = None

    if result is not None:
        if result["error"]:
            _set_timeline_database_status("ERROR", result["error"])
        else:
            if result["blocks"] != TIMELINE_BLOCKS:
                _set_timeline_blocks(bpy.context, result["blocks"])
            _remember_timeline_database_session()
            for scene in bpy.data.scenes:
                settings = getattr(scene, "blenderutils_timeline_settings", None)
                if settings is None:
                    continue
                settings.database_status = "CONNECTED"
                settings.database_message = ""
                settings.last_database_sync = result["synced_at"]
                settings.database_password = ""

    if time.monotonic() >= TIMELINE_SYNC_NEXT_AT:
        for scene in bpy.data.scenes:
            settings = getattr(scene, "blenderutils_timeline_settings", None)
            if settings is None or not settings.auto_sync_database:
                continue
            if TIMELINE_SESSION.get("access_token") or settings.database_password:
                _start_timeline_database_sync(settings.database_password)
                break
    return TIMELINE_TIMER_INTERVAL


def _draw_timeline_header_with_range_button(context, layout):
    scene = context.scene
    tool_settings = context.tool_settings
    screen = context.screen
    settings = scene.blenderutils_timeline_settings

    layout.separator_spacer()

    if settings.show_header_timeline_visibility:
        visibility_row = layout.row(align=True)
        toggle = visibility_row.operator(
            "blenderutils.toggle_timeline_blocks",
            text="",
            icon="HIDE_OFF" if settings.show_timeline_blocks else "HIDE_ON",
        )
        toggle.show = not settings.show_timeline_blocks
        visibility_row.popover(
            panel="BLENDERUTILS_PT_timeline_block_filter_popover",
            text="",
        )

    row = layout.row(align=True)
    row.prop(tool_settings, "use_keyframe_insert_auto", text="", toggle=True)
    sub = row.row(align=True)
    sub.active = tool_settings.use_keyframe_insert_auto
    sub.popover(
        panel="TIME_PT_auto_keyframing",
        text="",
    )

    row = layout.row(align=True)
    row.operator("screen.frame_jump", text="", icon='REW').end = False
    row.operator("screen.keyframe_jump", text="", icon='PREV_KEYFRAME').next = False
    if not screen.is_animation_playing:
        if scene.sync_mode == 'AUDIO_SYNC' and context.preferences.system.audio_device == 'JACK':
            row.scale_x = 2
            row.operator("screen.animation_play", text="", icon='PLAY')
            row.scale_x = 1
        else:
            row.operator("screen.animation_play", text="", icon='PLAY_REVERSE').reverse = True
            row.operator("screen.animation_play", text="", icon='PLAY')
    else:
        row.scale_x = 2
        row.operator("screen.animation_play", text="", icon='PAUSE')
        row.scale_x = 1
    row.operator("screen.keyframe_jump", text="", icon='NEXT_KEYFRAME').next = True
    row.operator("screen.frame_jump", text="", icon='FF').end = True

    if settings.show_header_center_current:
        layout.separator_spacer()
        layout.operator("blenderutils.center_current_frame", text="Center Current")
        layout.separator_spacer()

    row = layout.row(align=True)
    if scene.show_subframe:
        row.scale_x = 1.15
        row.prop(scene, "frame_float", text="")
    else:
        row.scale_x = 0.95
        row.prop(scene, "frame_current", text="")

    shift_buttons = (
        (10, settings.show_header_shift_10),
        (100, settings.show_header_shift_100),
        (600, settings.show_header_shift_600),
    )
    if any(visible for _, visible in shift_buttons):
        row.separator(factor=1)
        for offset, visible in shift_buttons:
            if not visible:
                continue
            button = row.operator("blenderutils.shift_current_frame", text=f"+{offset}")
            button.offset = offset

    if settings.show_header_range_to_selected:
        layout.operator("blenderutils.range_to_selected", text="Range To Selected")

    row = layout.row(align=True)
    row.prop(scene, "use_preview_range", text="", toggle=True)
    sub = row.row(align=True)
    sub.scale_x = 0.8
    if not scene.use_preview_range:
        if settings.show_header_current_to_start:
            button_row = sub.row(align=True)
            button_row.scale_x = 1.2
            button = button_row.operator(
                "blenderutils.current_to_range",
                text="",
                icon="TRIA_DOWN",
            )
            button.target = "START"
        sub.prop(scene, "frame_start", text="Start")
        sub.separator(factor=1.0)
        if settings.show_header_current_to_end:
            button_row = sub.row(align=True)
            button_row.scale_x = 1.2
            button = button_row.operator(
                "blenderutils.current_to_range",
                text="",
                icon="TRIA_DOWN",
            )
            button.target = "END"
        sub.prop(scene, "frame_end", text="End")
    else:
        if settings.show_header_current_to_start:
            button_row = sub.row(align=True)
            button_row.scale_x = 1.2
            button = button_row.operator(
                "blenderutils.current_to_range",
                text="",
                icon="TRIA_DOWN",
            )
            button.target = "START"
        sub.prop(scene, "frame_preview_start", text="Start")
        sub.separator(factor=1.0)
        if settings.show_header_current_to_end:
            button_row = sub.row(align=True)
            button_row.scale_x = 1.2
            button = button_row.operator(
                "blenderutils.current_to_range",
                text="",
                icon="TRIA_DOWN",
            )
            button.target = "END"
        sub.prop(scene, "frame_preview_end", text="End")


def _ensure_timeline_draw_handler():
    global TIMELINE_DRAW_HANDLER

    if TIMELINE_DRAW_HANDLER is None:
        TIMELINE_DRAW_HANDLER = bpy.types.SpaceDopeSheetEditor.draw_handler_add(
            _draw_timeline_blocks,
            (),
            "WINDOW",
            "POST_PIXEL",
        )


def _patch_time_header():
    global ORIGINAL_TIME_DRAW_HEADER

    if ORIGINAL_TIME_DRAW_HEADER is None:
        ORIGINAL_TIME_DRAW_HEADER = space_time.TIME_HT_editor_buttons.draw_header
        space_time.TIME_HT_editor_buttons.draw_header = staticmethod(_draw_timeline_header_with_range_button)


def _restore_time_header():
    global ORIGINAL_TIME_DRAW_HEADER

    if ORIGINAL_TIME_DRAW_HEADER is not None:
        space_time.TIME_HT_editor_buttons.draw_header = ORIGINAL_TIME_DRAW_HEADER
        ORIGINAL_TIME_DRAW_HEADER = None


def _remove_timeline_draw_handler():
    global TIMELINE_DRAW_HANDLER

    if TIMELINE_DRAW_HANDLER is not None:
        bpy.types.SpaceDopeSheetEditor.draw_handler_remove(TIMELINE_DRAW_HANDLER, "WINDOW")
        TIMELINE_DRAW_HANDLER = None


def _register_timeline_keymap():
    window_manager = bpy.context.window_manager
    addon_keyconfig = window_manager.keyconfigs.addon
    if not addon_keyconfig:
        return

    keymap = addon_keyconfig.keymaps.new(name="Dopesheet", space_type="DOPESHEET_EDITOR")
    keymap_item = keymap.keymap_items.new(
        BLENDERUTILS_OT_TimelineBlockDoubleClick.bl_idname,
        "LEFTMOUSE",
        "DOUBLE_CLICK",
    )
    TIMELINE_KEYMAPS.append((keymap, keymap_item))


def _unregister_timeline_keymap():
    for keymap, keymap_item in TIMELINE_KEYMAPS:
        keymap.keymap_items.remove(keymap_item)

    TIMELINE_KEYMAPS.clear()


def _timeline_filter_update(self, context):
    _tag_timeline_redraw(context)


class BLENDERUTILS_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    remember_database_login: bpy.props.BoolProperty(
        name="Remember Timeline Database Login",
        description="Stores an encrypted refresh token for automatic login",
        default=True,
    )
    encrypted_database_refresh_token: bpy.props.StringProperty(
        default="",
        options={"HIDDEN"},
    )

    def draw(self, context):
        self.layout.prop(self, "remember_database_login")


class BLENDERUTILS_PG_TimelineSettings(bpy.types.PropertyGroup):
    database_password: bpy.props.StringProperty(
        name="Access Password",
        description="Password used to connect to the shared timeline database",
        subtype="PASSWORD",
        options={"SKIP_SAVE"},
    )
    auto_sync_database: bpy.props.BoolProperty(
        name="Auto Sync",
        description="Checks the timeline database for changes every 10 seconds",
        default=True,
    )
    database_status: bpy.props.StringProperty(
        default="DISCONNECTED",
        options={"SKIP_SAVE"},
    )
    database_message: bpy.props.StringProperty(
        default="",
        options={"SKIP_SAVE"},
    )
    last_database_sync: bpy.props.StringProperty(
        default="",
        options={"SKIP_SAVE"},
    )
    show_timeline_blocks: bpy.props.BoolProperty(
        name="Show Timeline Blocks",
        description="Pokazuje lub ukrywa bloki timeline dodane przez addon",
        default=True,
    )
    show_loop_blocks: bpy.props.BoolProperty(
        name="Loop",
        description="Show loop blocks on the Timeline",
        default=True,
        update=_timeline_filter_update,
    )
    show_transition_blocks: bpy.props.BoolProperty(
        name="Transition",
        description="Show transition blocks on the Timeline",
        default=True,
        update=_timeline_filter_update,
    )
    show_story_blocks: bpy.props.BoolProperty(
        name="Story",
        description="Show story blocks on the Timeline",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_timeline_visibility: bpy.props.BoolProperty(
        name="Timeline Visibility",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_center_current: bpy.props.BoolProperty(
        name="Center Current",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_shift_10: bpy.props.BoolProperty(
        name="+10",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_shift_100: bpy.props.BoolProperty(
        name="+100",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_shift_600: bpy.props.BoolProperty(
        name="+600",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_range_to_selected: bpy.props.BoolProperty(
        name="Range To Selected",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_current_to_start: bpy.props.BoolProperty(
        name="Current To Start",
        default=True,
        update=_timeline_filter_update,
    )
    show_header_current_to_end: bpy.props.BoolProperty(
        name="Current To End",
        default=True,
        update=_timeline_filter_update,
    )
    show_camera_manager: bpy.props.BoolProperty(
        name="Show Camera Manager",
        description="Pokazuje panel z dropdownem i listą kamer",
        default=False,
    )


class BLENDERUTILS_OT_SetTimelineBlockVisibility(bpy.types.Operator):
    bl_label = "Set Timeline Block Visibility"
    bl_idname = "blenderutils.set_timeline_block_visibility"
    bl_description = "Shows or hides all Timeline block types"

    show: bpy.props.BoolProperty()

    def execute(self, context):
        settings = context.scene.blenderutils_timeline_settings
        settings.show_loop_blocks = self.show
        settings.show_transition_blocks = self.show
        settings.show_story_blocks = self.show
        _tag_timeline_redraw(context)
        return {"FINISHED"}


class BLENDERUTILS_PT_TimelineBlockFilterPopover(bpy.types.Panel):
    bl_label = "Timeline Block Filters"
    bl_idname = "BLENDERUTILS_PT_timeline_block_filter_popover"
    bl_space_type = "DOPESHEET_EDITOR"
    bl_region_type = "HEADER"

    def draw(self, context):
        settings = context.scene.blenderutils_timeline_settings
        layout = self.layout
        layout.label(text="Visible Block Types", icon="FILTER")

        column = layout.column(align=True)
        for property_name, label in (
            ("show_loop_blocks", "Loop"),
            ("show_transition_blocks", "Transition"),
            ("show_story_blocks", "Story"),
        ):
            visible = getattr(settings, property_name)
            column.prop(
                settings,
                property_name,
                text=label,
                icon="CHECKBOX_HLT" if visible else "CHECKBOX_DEHLT",
                toggle=True,
            )

        layout.separator()
        row = layout.row(align=True)
        show_all = row.operator(
            "blenderutils.set_timeline_block_visibility",
            text="All",
            icon="CHECKMARK",
        )
        show_all.show = True
        hide_all = row.operator(
            "blenderutils.set_timeline_block_visibility",
            text="None",
            icon="X",
        )
        hide_all.show = False


class BLENDERUTILS_PG_CameraItem(bpy.types.PropertyGroup):
    area: bpy.props.StringProperty()
    frame_count: bpy.props.IntProperty(default=0)
    exists_in_scene: bpy.props.BoolProperty(default=False)


def _camera_search_update(self, context):
    query = self.camera_search.strip().lower()
    if query:
        self.camera_area = "ALL"
    if not query:
        return
    for index, item in enumerate(self.camera_items):
        if query in item.name.lower():
            self.active_camera_index = index
            break


def _camera_matches_filter(camera_name, filter_name):
    if filter_name == "NO_FILTER":
        return True
    if filter_name == "ERRORS":
        return not _camera_exists(camera_name)

    expected_type = {
        "LOOPS": "loop",
        "TRANSITIONS": "transition",
        "STORIES": "story",
    }.get(filter_name)
    return any(
        block.get("camera") == camera_name and block.get("type") == expected_type
        for block in TIMELINE_BLOCKS
    )


class BLENDERUTILS_PG_CameraManagerSettings(bpy.types.PropertyGroup):
    camera_area: bpy.props.EnumProperty(
        name="Area",
        description="Wybierz obszar kamer z aktualnie wczytanego timeline",
        items=_camera_area_items,
    )
    camera_items: bpy.props.CollectionProperty(type=BLENDERUTILS_PG_CameraItem)
    active_camera_index: bpy.props.IntProperty(default=0)
    camera_search: bpy.props.StringProperty(
        name="Search Camera",
        description="Filters the camera list",
        update=_camera_search_update,
    )
    camera_filter: bpy.props.EnumProperty(
        name="Filter",
        items=(
            ("NO_FILTER", "No filter", "Show all cameras"),
            ("LOOPS", "Show loops", "Show loop cameras"),
            ("TRANSITIONS", "Show transitions", "Show transition cameras"),
            ("STORIES", "Show stories", "Show story cameras"),
            ("ERRORS", "Show errors", "Show missing cameras"),
        ),
        default="NO_FILTER",
    )


class BLENDERUTILS_UL_CameraList(bpy.types.UIList):
    def filter_items(self, context, data, propname):
        self.use_filter_show = False
        self.use_filter_sort_alpha = False
        settings = context.scene.blenderutils_camera_manager_settings
        items = getattr(data, propname)
        flags = []
        for item in items:
            matches_area = settings.camera_area == "ALL" or item.area == settings.camera_area
            matches_search = (
                not settings.camera_search.strip() or
                settings.camera_search.strip().lower() in item.name.lower()
            )
            matches_filter = _camera_matches_filter(item.name, settings.camera_filter)
            flags.append(
                self.bitflag_filter_item
                if matches_area and matches_search and matches_filter
                else 0
            )
        return flags, []

    def draw_filter(self, context, layout):
        pass

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        split = layout.split(factor=0.08, align=True)
        exists_in_scene = _camera_exists(item.name)
        split.label(icon="CAMERA_DATA" if exists_in_scene else "ERROR")
        columns = split.row(align=True)
        name_column = columns.split(factor=0.72, align=True)
        name_column.label(text=item.name)
        name_column.label(text=f"{item.frame_count} f")


class BLENDERUTILS_PT_MainPanel(bpy.types.Panel):
    bl_label = "Blender Utils"
    bl_idname = "BLENDERUTILS_PT_main_panel"

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Blender Utils"

    def draw(self, context):
        self.layout.label(text="Shared Timeline", icon="TIME")


class BLENDERUTILS_PT_CameraManager(bpy.types.Panel):
    bl_label = "Camera Manager"
    bl_idname = "BLENDERUTILS_PT_camera_manager"
    bl_parent_id = "BLENDERUTILS_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Blender Utils"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        settings = getattr(context.scene, "blenderutils_timeline_settings", None)
        return bool(settings and settings.show_camera_manager)

    def draw(self, context):
        settings = context.scene.blenderutils_camera_manager_settings
        layout = self.layout
        active_item = (
            settings.camera_items[settings.active_camera_index]
            if 0 <= settings.active_camera_index < len(settings.camera_items)
            else None
        )
        validation_box = layout.box()
        missing_frames = []
        transition_validation = None
        issues = []
        camera_name = active_item.name if active_item else ""
        camera = bpy.data.objects.get(camera_name) if active_item else None

        if active_item is None:
            validation_box.label(text="No camera selected", icon="INFO")
        else:
            camera_row = validation_box.row(align=True)
            camera_row.label(text=f"Camera: {camera_name}", icon="CAMERA_DATA")
            if camera and camera.type == "CAMERA":
                camera_row.label(text=f"Focal Length: {camera.data.lens:.1f} mm")
            blocks = _camera_timeline_blocks(camera_name)
            keyframe_row = validation_box.row(align=True)
            keyframe_row.label(text="Timeline Keyframes:")
            keyframe_row.label(
                text=", ".join(
                    f"{block['start_frame']} - {block['end_frame']}" for block in blocks
                ) if blocks else "None"
            )

            if camera and camera.type == "CAMERA":
                missing_frames = _camera_missing_timeline_keyframes(camera, camera_name)
                if missing_frames:
                    issues.append(
                        "Missing Keyframes: " + ", ".join(map(str, missing_frames))
                    )

                transition_validation = _transition_validation_issues(camera, camera_name)
                if transition_validation:
                    components, transition_issues = transition_validation
                    for endpoint, component in (("start", components[0]), ("end", components[1])):
                        if transition_issues[endpoint]:
                            issues.append(
                                f"{endpoint.title()} / {component}: "
                                + "; ".join(transition_issues[endpoint])
                            )
            else:
                issues.append("Camera is missing")

            status_row = validation_box.row(align=True)
            if issues:
                status_row.label(text=issues[0], icon="ERROR")
            else:
                status_row.label(text="No Issues", icon="CHECKMARK")
            fix_button = status_row.row(align=True)
            fix_button.scale_x = 0.65
            fix_button.enabled = bool(camera and camera.type == "CAMERA" and issues)
            operator = fix_button.operator(
                "blenderutils.fix_camera_issues",
                text="Fix",
                icon="TOOL_SETTINGS",
            )
            operator.camera_name = camera_name
            for issue in issues[1:]:
                validation_box.label(text=issue, icon="ERROR")

        layout.prop(settings, "camera_area", text="Area")
        list_box = layout.box()
        header = list_box.row(align=True)
        header_split = header.split(factor=0.08, align=True)
        header_split.label(text="")
        header_columns = header_split.row(align=True)
        header_name = header_columns.split(factor=0.72, align=True)
        header_name.label(text="Camera")
        header_name.label(text="Length")
        list_box.template_list(
            "BLENDERUTILS_UL_CameraList",
            "camera_items",
            settings,
            "camera_items",
            settings,
            "active_camera_index",
            rows=5,
        )
        search_row = list_box.row(align=True)
        search_row.prop(settings, "camera_search", text="", icon="VIEWZOOM")
        search_row.operator("blenderutils.clear_camera_search", text="", icon="X")
        search_row.prop(settings, "camera_filter", text="")
        row = layout.row()
        row.enabled = bool(active_item and not _camera_exists(active_item.name))
        operator = row.operator("blenderutils.add_camera_from_view", text="Add Camera", icon="ADD")
        if active_item:
            operator.camera_name = active_item.name
        row = layout.row()
        row.enabled = bool(active_item and _camera_exists(active_item.name))
        operator = row.operator(
            "blenderutils.select_camera_and_frame",
            text="Jump to Camera",
            icon="RESTRICT_SELECT_OFF",
        )
        if active_item:
            operator.camera_name = active_item.name


class BLENDERUTILS_PT_TimelinePanel(bpy.types.Panel):
    bl_label = "Camera Timeline"
    bl_idname = "BLENDERUTILS_PT_timeline_panel"
    bl_parent_id = "BLENDERUTILS_PT_main_panel"

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Blender Utils"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        settings = context.scene.blenderutils_timeline_settings
        status_icons = {
            "DISCONNECTED": "UNLINKED",
            "CONNECTING": "SORTTIME",
            "CONNECTED": "CHECKMARK",
            "ERROR": "ERROR",
        }

        status_box = layout.box()
        status_box.label(
            text=settings.database_status.title(),
            icon=status_icons.get(settings.database_status, "QUESTION"),
        )
        if settings.database_message:
            status_box.label(text=settings.database_message[:90], icon="INFO")
        if settings.last_database_sync:
            status_box.label(text=f"Last sync: {settings.last_database_sync}")

        if settings.database_status in {"DISCONNECTED", "ERROR"}:
            layout.prop(settings, "database_password", text="Password")
            preferences = _get_addon_preferences()
            if preferences is not None:
                layout.prop(
                    preferences,
                    "remember_database_login",
                    text="Remember Login",
                )
            layout.operator(
                "blenderutils.connect_timeline_database",
                text="Connect",
                icon="LINKED",
            )
        else:
            layout.prop(settings, "auto_sync_database", text="Auto Sync", toggle=True)
            row = layout.row(align=True)
            row.enabled = settings.database_status != "CONNECTING"
            row.operator(
                "blenderutils.refresh_timeline_database",
                text="Sync Now",
                icon="FILE_REFRESH",
            )
            row.operator(
                "blenderutils.disconnect_timeline_database",
                text="Disconnect",
                icon="UNLINKED",
            )

        layout.separator()
        layout.prop(settings, "show_timeline_blocks", text="Show Timeline Blocks")

        header_box = layout.box()
        header_box.label(text="Timeline Header Buttons", icon="PREFERENCES")
        grid = header_box.grid_flow(
            row_major=True,
            columns=2,
            even_columns=True,
            even_rows=False,
            align=True,
        )
        for property_name in (
            "show_header_timeline_visibility",
            "show_header_center_current",
            "show_header_shift_10",
            "show_header_shift_100",
            "show_header_shift_600",
            "show_header_range_to_selected",
            "show_header_current_to_start",
            "show_header_current_to_end",
        ):
            grid.prop(settings, property_name)


class BLENDERUTILS_OT_SpawnSphere(bpy.types.Operator):
    bl_label = "Spawn Sphere"
    bl_idname = "blenderutils.spawn_sphere"
    bl_description = "Adds a sphere at the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cursor_location = context.scene.cursor.location

        bpy.ops.mesh.primitive_uv_sphere_add(
            segments=32,
            ring_count=16,
            radius=1.0,
            location=cursor_location,
        )

        sphere = context.object
        if sphere:
            sphere.name = "Weidmuller Sphere"

        return {"FINISHED"}


class BLENDERUTILS_OT_ClearCameraSearch(bpy.types.Operator):
    bl_label = "Clear Camera Search"
    bl_idname = "blenderutils.clear_camera_search"
    bl_description = "Clears the camera search"

    def execute(self, context):
        context.scene.blenderutils_camera_manager_settings.camera_search = ""
        return {"FINISHED"}


class BLENDERUTILS_OT_FixCameraIssues(bpy.types.Operator):
    bl_label = "Fix Camera Issues"
    bl_idname = "blenderutils.fix_camera_issues"
    bl_description = "Fixes missing Timeline keyframes and transition endpoint settings"
    bl_options = {"REGISTER", "UNDO"}

    camera_name: bpy.props.StringProperty()

    def execute(self, context):
        camera = bpy.data.objects.get(self.camera_name)
        if camera is None or camera.type != "CAMERA":
            self.report({"ERROR"}, "Camera is missing")
            return {"CANCELLED"}

        missing_frames = _camera_missing_timeline_keyframes(camera, self.camera_name)
        for frame in missing_frames:
            camera.keyframe_insert(data_path="location", frame=frame)
            camera.keyframe_insert(data_path="rotation_euler", frame=frame)

        transition_fixed = _fix_transition_camera_issues(camera, self.camera_name)
        if missing_frames or transition_fixed:
            self.report({"INFO"}, "Camera issues fixed")
        else:
            self.report({"WARNING"}, "No fixable issues found")
        return {"FINISHED"}


class BLENDERUTILS_OT_AddCameraFromView(bpy.types.Operator):
    bl_label = "Add Camera"
    bl_idname = "blenderutils.add_camera_from_view"
    bl_description = "Adds the missing camera from the current 3D view"

    camera_name: bpy.props.StringProperty()

    def execute(self, context):
        camera_name = self.camera_name.strip()
        if not camera_name:
            return {"CANCELLED"}
        if bpy.data.objects.get(camera_name):
            self.report({"WARNING"}, f"Camera {camera_name} already exists.")
            return {"CANCELLED"}

        transition_block = next(
            (
                block for block in TIMELINE_BLOCKS
                if block.get("camera") == camera_name and block.get("type") == "transition"
            ),
            None,
        )
        if transition_block:
            return self._create_transition_camera(context, camera_name, transition_block)

        bpy.ops.object.camera_add(location=context.scene.cursor.location)
        camera = context.object
        camera.name = camera_name
        camera.data.name = camera_name
        context.scene.camera = camera

        if context.area and context.area.type == "VIEW_3D":
            bpy.ops.view3d.camera_to_view()

        _add_tracking_target(camera, _camera_tracking_point(camera))
        _insert_camera_timeline_keyframes(camera, camera_name)
        _refresh_camera_manager_items(context)
        self.report({"INFO"}, f"Added camera {camera_name}.")
        return {"FINISHED"}

    def _create_transition_camera(self, context, camera_name, transition_block):
        return BLENDERUTILS_OT_SelectCameraAndFrame._create_transition_camera(
            self,
            context,
            camera_name,
            transition_block,
        )


class BLENDERUTILS_OT_SelectCameraAndFrame(bpy.types.Operator):
    bl_label = "Select Camera"
    bl_idname = "blenderutils.select_camera_and_frame"
    bl_description = "Selects the camera and jumps to its first Timeline block"

    camera_name: bpy.props.StringProperty()

    def execute(self, context):
        camera = bpy.data.objects.get(self.camera_name)
        if camera is None or camera.type != "CAMERA":
            return {"CANCELLED"}

        for obj in context.view_layer.objects:
            obj.select_set(False)
        camera.select_set(True)
        context.view_layer.objects.active = camera

        camera_blocks = [
            block for block in TIMELINE_BLOCKS
            if block.get("camera") == self.camera_name
        ]
        if camera_blocks:
            first_frame = min(block["start_frame"] for block in camera_blocks)
            context.scene.frame_set(first_frame)
            _tag_timeline_redraw(context)

        return {"FINISHED"}

    def _create_transition_camera(self, context, camera_name, transition_block):
        component_names = [part.strip() for part in camera_name.split("-") if part.strip()]
        if len(component_names) == 2:
            previous_camera = bpy.data.objects.get(component_names[0])
            next_camera = bpy.data.objects.get(component_names[1])
            if (
                previous_camera is None or previous_camera.type != "CAMERA" or
                next_camera is None or next_camera.type != "CAMERA"
            ):
                missing = component_names[
                    0 if previous_camera is None or previous_camera.type != "CAMERA" else 1
                ]
                self.report(
                    {"ERROR"},
                    f"Cannot add transition {camera_name}: camera {missing} is missing.",
                )
                return {"CANCELLED"}
        else:
            previous_camera = None
            next_camera = None

        ordered_blocks = sorted(
            TIMELINE_BLOCKS,
            key=lambda block: (block["start_frame"], block["end_frame"]),
        )
        block_index = ordered_blocks.index(transition_block)
        if previous_camera is None or next_camera is None:
            for block in reversed(ordered_blocks[:block_index]):
                candidate = bpy.data.objects.get(block.get("camera"))
                if candidate and candidate.type == "CAMERA":
                    previous_camera = candidate
                    break
            for block in ordered_blocks[block_index + 1:]:
                candidate = bpy.data.objects.get(block.get("camera"))
                if candidate and candidate.type == "CAMERA":
                    next_camera = candidate
                    break

        if previous_camera is None or next_camera is None:
            self.report(
                {"ERROR"},
                "A transition requires existing cameras before and after the block.",
            )
            return {"CANCELLED"}

        curve_data = bpy.data.curves.new(f"Curve_{camera_name}", type="CURVE")
        curve_data.dimensions = "3D"
        curve_data.resolution_u = 24
        curve_data.path_duration = max(
            1,
            int(transition_block["end_frame"] - transition_block["start_frame"]),
        )
        spline = curve_data.splines.new("BEZIER")
        spline.bezier_points.add(1)
        # Keep the curve points in the same order as the transition name:
        # camera A first, camera B second.
        transition_start_frame = transition_block["start_frame"]
        transition_end_frame = transition_block["end_frame"]
        spline.bezier_points[0].co = _object_location_at_frame(previous_camera, transition_start_frame)
        spline.bezier_points[1].co = _object_location_at_frame(next_camera, transition_end_frame)
        for point in spline.bezier_points:
            point.handle_left_type = "AUTO"
            point.handle_right_type = "AUTO"

        curve_object = bpy.data.objects.new(f"Curve_{camera_name}", curve_data)
        context.collection.objects.link(curve_object)

        camera_data = bpy.data.cameras.new(camera_name)
        camera = bpy.data.objects.new(camera_name, camera_data)
        context.collection.objects.link(camera)
        camera.animation_data_clear()
        camera.location = (0.0, 0.0, 0.0)
        camera.rotation_euler = (0.0, 0.0, 0.0)
        camera.data.lens = previous_camera.data.lens
        camera.data.keyframe_insert(data_path="lens", frame=transition_block["start_frame"])
        camera.data.lens = next_camera.data.lens
        camera.data.keyframe_insert(data_path="lens", frame=transition_block["end_frame"])
        camera.data.lens = previous_camera.data.lens

        constraint = camera.constraints.new(type="FOLLOW_PATH")
        constraint.name = "Transition Follow Path"
        constraint.target = curve_object
        constraint.forward_axis = "FORWARD_X"
        constraint.up_axis = "UP_Y"
        constraint.use_fixed_location = True
        constraint.use_curve_follow = False
        constraint.offset_factor = 0.0
        constraint.keyframe_insert(data_path="offset_factor", frame=transition_block["start_frame"])
        constraint.offset_factor = 1.0
        constraint.keyframe_insert(data_path="offset_factor", frame=transition_block["end_frame"])

        previous_target = _camera_tracking_target(previous_camera)
        next_target = _camera_tracking_target(next_camera)
        _add_tracking_target(
            camera,
            _object_location_at_frame(previous_target, transition_start_frame)
            if previous_target else _camera_tracking_point(previous_camera),
            _object_location_at_frame(next_target, transition_end_frame)
            if next_target else _camera_tracking_point(next_camera),
            transition_start_frame,
            transition_end_frame,
        )
        _insert_camera_timeline_keyframes(camera, camera_name)

        context.scene.camera = camera
        self.report({"INFO"}, f"Added transition camera {camera_name} with Follow Path.")
        return {"FINISHED"}


class BLENDERUTILS_OT_ConnectTimelineDatabase(bpy.types.Operator):
    bl_label = "Connect Timeline Database"
    bl_idname = "blenderutils.connect_timeline_database"
    bl_description = "Connects to the shared timeline database"

    def execute(self, context):
        settings = context.scene.blenderutils_timeline_settings
        if not settings.database_password and not TIMELINE_SESSION.get("access_token"):
            self.report({"ERROR"}, "Enter the access password.")
            return {"CANCELLED"}
        if settings.database_password:
            TIMELINE_SESSION["access_token"] = None
            TIMELINE_SESSION["refresh_token"] = None
            _forget_timeline_database_session()
        settings.database_status = "CONNECTING"
        settings.database_message = ""
        settings.auto_sync_database = True
        if not _start_timeline_database_sync(settings.database_password):
            self.report({"INFO"}, "Timeline synchronization is already running.")
        return {"FINISHED"}


class BLENDERUTILS_OT_RefreshTimelineDatabase(bpy.types.Operator):
    bl_label = "Sync Timeline Database"
    bl_idname = "blenderutils.refresh_timeline_database"
    bl_description = "Immediately downloads the newest timeline blocks"

    def execute(self, context):
        settings = context.scene.blenderutils_timeline_settings
        if not TIMELINE_SESSION.get("access_token") and not settings.database_password:
            self.report({"ERROR"}, "Connect to the timeline database first.")
            return {"CANCELLED"}
        settings.database_status = "CONNECTING"
        settings.database_message = ""
        if not _start_timeline_database_sync(settings.database_password):
            self.report({"INFO"}, "Timeline synchronization is already running.")
        return {"FINISHED"}


class BLENDERUTILS_OT_DisconnectTimelineDatabase(bpy.types.Operator):
    bl_label = "Disconnect Timeline Database"
    bl_idname = "blenderutils.disconnect_timeline_database"
    bl_description = "Ends the current database session and clears timeline blocks"

    def execute(self, context):
        global TIMELINE_SYNC_RESULT, TIMELINE_SYNC_NEXT_AT
        TIMELINE_SESSION["access_token"] = None
        TIMELINE_SESSION["refresh_token"] = None
        _forget_timeline_database_session()
        with TIMELINE_SYNC_LOCK:
            TIMELINE_SYNC_RESULT = None
        TIMELINE_SYNC_NEXT_AT = 0.0
        for scene in bpy.data.scenes:
            settings = getattr(scene, "blenderutils_timeline_settings", None)
            if settings is None:
                continue
            settings.database_password = ""
            settings.database_status = "DISCONNECTED"
            settings.database_message = ""
            settings.last_database_sync = ""
            settings.auto_sync_database = False
        _set_timeline_blocks(context, [])
        return {"FINISHED"}


class BLENDERUTILS_OT_ToggleTimelineBlocks(bpy.types.Operator):
    bl_label = "Toggle Timeline Blocks"
    bl_idname = "blenderutils.toggle_timeline_blocks"
    bl_description = "Shows or hides the timeline blocks drawn by the addon"

    show: bpy.props.BoolProperty()

    def execute(self, context):
        settings = context.scene.blenderutils_timeline_settings
        settings.show_timeline_blocks = self.show
        _tag_timeline_redraw(context)
        return {"FINISHED"}


class BLENDERUTILS_OT_TimelineBlockDoubleClick(bpy.types.Operator):
    bl_label = "Set Timeline Range From Block"
    bl_idname = "blenderutils.timeline_block_double_click"
    bl_description = "Sets the render range from the clicked block"

    def invoke(self, context, event):
        if context.area.type != "DOPESHEET_EDITOR":
            return {"PASS_THROUGH"}

        mouse_x = event.mouse_region_x
        mouse_y = event.mouse_region_y

        for item in reversed(TIMELINE_BLOCK_RECTS):
            inside_x = item["x"] <= mouse_x <= item["x"] + item["width"]
            inside_y = item["y"] <= mouse_y <= item["y"] + item["height"]
            if not inside_x or not inside_y:
                continue

            block = item["block"]
            context.scene.frame_start = block["start_frame"]
            context.scene.frame_end = block["end_frame"]
            context.scene.frame_set(block["start_frame"])
            _tag_timeline_redraw(context)

            return {"FINISHED"}

        return {"PASS_THROUGH"}


class BLENDERUTILS_OT_ShiftCurrentFrame(bpy.types.Operator):
    bl_label = "Shift Current Frame"
    bl_idname = "blenderutils.shift_current_frame"
    bl_description = "Shifts the current frame by the selected frame count"

    offset: bpy.props.IntProperty()

    def invoke(self, context, event):
        direction = -1 if event.shift or event.ctrl else 1
        context.scene.frame_set(context.scene.frame_current + direction * self.offset)
        return {"FINISHED"}


class BLENDERUTILS_OT_CurrentToRange(bpy.types.Operator):
    bl_label = "Current Frame To Range"
    bl_idname = "blenderutils.current_to_range"
    bl_description = "Sets the range start or end to the current frame"

    target: bpy.props.EnumProperty(
        items=(
            ("START", "Start", "Sets the range start"),
            ("END", "End", "Sets the range end"),
        )
    )

    def execute(self, context):
        scene = context.scene
        current_frame = scene.frame_current
        if scene.use_preview_range:
            if self.target == "START":
                scene.frame_preview_start = current_frame
            else:
                scene.frame_preview_end = current_frame
        elif self.target == "START":
            scene.frame_start = current_frame
        else:
            scene.frame_end = current_frame
        return {"FINISHED"}


class BLENDERUTILS_OT_CenterCurrentFrame(bpy.types.Operator):
    bl_label = "Center Current Frame"
    bl_idname = "blenderutils.center_current_frame"
    bl_description = "Centers the Timeline view on the current frame"

    def execute(self, context):
        if context.area is None or context.area.type != "DOPESHEET_EDITOR":
            return {"CANCELLED"}

        area = context.area
        region = next((item for item in area.regions if item.type == "WINDOW"), None)
        if region is None:
            return {"CANCELLED"}

        frame = float(context.scene.frame_current)
        target_x = region.width * 0.5
        view_2d = region.view2d

        with context.temp_override(area=area, region=region, space_data=area.spaces.active):
            for _ in range(300):
                current_x = view_2d.view_to_region(frame, 0.0, clip=False)[0]
                delta = current_x - target_x
                if abs(delta) < 2.0:
                    break
                steps = max(1, min(12, int(abs(delta) / 90.0) + 1))
                for _ in range(steps):
                    if delta > 0:
                        bpy.ops.view2d.scroll_right()
                    else:
                        bpy.ops.view2d.scroll_left()

        area.tag_redraw()
        return {"FINISHED"}


class BLENDERUTILS_OT_RangeToSelected(bpy.types.Operator):
    bl_label = "Range To Selected"
    bl_idname = "blenderutils.range_to_selected"
    bl_description = "Sets the Timeline range from the active object's first and last keyframe"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        frame_range = _get_selected_object_frame_range(context.active_object)
        if frame_range is None:
            self.report({"ERROR"}, "The active object has no keyframes.")
            return {"CANCELLED"}

        start_frame, end_frame = frame_range
        context.scene.frame_start = start_frame
        context.scene.frame_end = end_frame
        context.scene.frame_set(start_frame)
        _tag_timeline_redraw(context)

        return {"FINISHED"}


classes = (
    BLENDERUTILS_AddonPreferences,
    BLENDERUTILS_PG_TimelineSettings,
    BLENDERUTILS_OT_SetTimelineBlockVisibility,
    BLENDERUTILS_PT_TimelineBlockFilterPopover,
    BLENDERUTILS_OT_SpawnSphere,
    BLENDERUTILS_OT_ConnectTimelineDatabase,
    BLENDERUTILS_OT_RefreshTimelineDatabase,
    BLENDERUTILS_OT_DisconnectTimelineDatabase,
    BLENDERUTILS_OT_ToggleTimelineBlocks,
    BLENDERUTILS_OT_TimelineBlockDoubleClick,
    BLENDERUTILS_OT_ShiftCurrentFrame,
    BLENDERUTILS_OT_CurrentToRange,
    BLENDERUTILS_OT_CenterCurrentFrame,
    BLENDERUTILS_OT_RangeToSelected,
    BLENDERUTILS_PT_MainPanel,
    BLENDERUTILS_PT_TimelinePanel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.blenderutils_timeline_settings = bpy.props.PointerProperty(
        type=BLENDERUTILS_PG_TimelineSettings
    )

    _patch_time_header()
    _ensure_timeline_draw_handler()
    _register_timeline_keymap()

    if not bpy.app.timers.is_registered(_timeline_database_auto_refresh_timer):
        bpy.app.timers.register(_timeline_database_auto_refresh_timer, persistent=True)

    if _restore_timeline_database_session():
        for scene in bpy.data.scenes:
            settings = scene.blenderutils_timeline_settings
            settings.database_status = "CONNECTING"
            settings.database_message = ""
            settings.auto_sync_database = True
        _start_timeline_database_sync()


def unregister():
    if bpy.app.timers.is_registered(_timeline_database_auto_refresh_timer):
        bpy.app.timers.unregister(_timeline_database_auto_refresh_timer)

    _unregister_timeline_keymap()
    _remove_timeline_draw_handler()
    _restore_time_header()
    if hasattr(bpy.types.Scene, "blenderutils_timeline_settings"):
        del bpy.types.Scene.blenderutils_timeline_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
